# cs165
Revive ma boi

Compile with "g++ cs165_lab1.cpp hashlib2plus/trunk/src/*.cpp"

1. Source code is cs165_lab1.cpp
2. Number of threads = n
3. CPU model = Intel(R) Core(TM) i7-855OU CPU @1.80GHz
4. Passwords tested/second = 

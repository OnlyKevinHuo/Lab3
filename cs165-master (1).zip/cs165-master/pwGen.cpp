// Generates aaaaa --> zzzzzz
//Source file https://stackoverflow.com/questions/10159649/generate-all-letter-combinations/10161603#10161603
#include <stdio.h>
#include <string.h>

void iterate(char *str, int idx, int len) {
    char c;

    if (idx < (len - 1)) {
        for (c = 'a'; c <= 'z'; ++c) {
            str[idx] = c;

            iterate(str, idx + 1, len);
        }
    } else {
        for (c = 'a'; c <= 'z'; ++c) {
            str[idx] = c;

            printf("%s\n", str);
        }
    }
}

#define LEN 6

int main(int argc, char **argv) {
    char str[LEN + 1];

    memset(str, 0, LEN + 1);

    iterate(str, 0, LEN);
}